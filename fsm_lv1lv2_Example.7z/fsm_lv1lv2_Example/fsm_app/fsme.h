/**
  ******************************************************************************
  * @file    fsme.h
  * @author  SeanLi
  * @version 
  * @date    04-December-2017
  * @brief   
  *
  *                      
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

/*******************************************************************************
********************* Define to prevent recursive inclusion ********************
*******************************************************************************/
#ifndef _FSME_H
#define _FSME_H

/*******************************************************************************
************************************ Includes **********************************
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//平台依赖
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"


/*******************************************************************************
********************************* Exported macro *******************************
*******************************************************************************/
#define ARRAY_SIZE(arr)     (sizeof(arr) / sizeof((arr)[0]))
#define ARRAY_AND_SIZE(x)	(x), ARRAY_SIZE(x)

//平台依赖
#define fsme_get_tick_count	xTaskGetTickCount

#define FSME_DEBUG_LEVEL      2

#if (FSME_DEBUG_LEVEL > 0)
#define	fsme_usr_log(...)   printf(__VA_ARGS__);

#else
#define	fsme_usr_log(...)   
#endif            
                            
#if (FSME_DEBUG_LEVEL > 1)

#define	fsme_err_log(...)   printf(__VA_ARGS__);


#else
#define	fsme_err_log(...)   
#endif                         
                            
#if (FSME_DEBUG_LEVEL > 2)                         
#define	fsme_dbg_log(...)   printf(__VA_ARGS__);
                            

#else
#define	fsme_dbg_log(...)                         
#endif

#define true  1
#define false 0
	
/*******************************************************************************
********************************* Exported types *******************************
*******************************************************************************/

//平台依赖
typedef unsigned int fsme_int_t;

typedef fsme_int_t 	(*fsme_event_t)(void *fsmp);//定义函数指针fsme_event_t,格式为int xxx(void *)
typedef void 		(*fsme_func_t)(void *fsmp); //定义函数指针fsme_func_t,格式为void xxx(void *)

//转移结构体(转移判断函数+转移到的状态)
typedef struct {
	fsme_event_t	event; 		/* pointer to an event (input) function */
	fsme_int_t 		next_state;
	
}fsme_trans_t;

//状态项结构体(描述一个具体状态, 状态函数,进入函数,退出函数,转移列表,状态名称)
typedef struct {
	/* pointer to action function and entry/exit functions;
	 * Action function is mandatory and entry/exit function are optional.
	 */
	fsme_func_t 	action;
	fsme_func_t 	entry_action;
	fsme_func_t 	exit_action;
	
	/* an array that contains the actual transitions infromation:
	 * pairs (event, next state) */
	const fsme_trans_t * trans;
	
	/*the number of transitions from the state */
	fsme_int_t	trans_nbr; 
	char 		*name;
	
}fsme_state_t;

/* FSM descriptor 状态机结构体(包含多个子状态)
(使能与否, 当前状态号, 状态列表, 状态列表长, 当前状态的转移列表, 当前状态转移列表长,
当前状态超时时间, 超时标志, 此状态的进入状态, 进入此状态的转移事件)*/
typedef struct {
	fsme_int_t 	enable;
	
	fsme_int_t 	current_state;
	const fsme_state_t *states;		/* an array that contains the states and transitions of the FSM */
	fsme_int_t 	states_nbr; 		/* the number of states of the FSM */
	
	const fsme_trans_t *trans; 		/* reference to an array with the transitions form current state */
	fsme_int_t 	trans_nbr; 			/* the number of transitions from current state */

    fsme_int_t 	timeout; 			/* timeout OS tick for current state */
    fsme_int_t 	timeout_flag; 		/* 超时事件已经发生时为1，在进入新的状态时清零 */
    fsme_int_t 	timer;       		/* 定时器 备用 */
    fsme_int_t 	last_state;   		/* 跳转之前的状态  */
    fsme_int_t 	last_event;   		/* 跳转之前的触发的事件 */

	//fsme_int_t err_exit; 			/* flag to notify that current FSM exit on error */
	//fsme_int_t finish_exit; 		/* flag to notify that current FSM exit on finish */
	
	fsme_func_t fsm_entry;          //【状态机的使能执行函数】
	fsme_func_t fsm_exit;           //【状态机的禁能执行函数】
	fsme_int_t 	exit_flag;			// 退出条件，替代 err_exit 和 finish_exit
	
	char 	*name;
	
} fsme_t;


/*******************************************************************************
******************************* Exported constants *****************************
*******************************************************************************/

/*******************************************************************************
******************************* Exported functions *****************************
*******************************************************************************/

void fsm_run(fsme_t *fsm);
void fsm_enable(fsme_t *fsm);
void fsm_disable(fsme_t *fsm);

#endif /* _FSME_H */

/********************************* end of file ********************************/



