/**
  ******************************************************************************
  * @file    fsm_lv1.c
  * @author  SeanLi
  * @version 
  * @date    04-December-2017
  * @brief   
  *
  *                      
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

/*******************************************************************************
************************************ Includes **********************************
*******************************************************************************/

#include "fsm_lv1.h"
#include "fsm_lv1_action.h"
#include "fsm_lv1_event.h"
#include "fsm_lv2.h"


/*******************************************************************************
******************************** Private typedef *******************************
*******************************************************************************/

/*******************************************************************************
******************************** Private define ********************************
*******************************************************************************/

/*******************************************************************************
********************************* Private macro ********************************
*******************************************************************************/

/*******************************************************************************
******************************* Private variables ******************************
*******************************************************************************/

/*******************************************************************************
************************** Private function prototypes *************************
*******************************************************************************/

/*******************************************************************************
******************************* Private functions ******************************
*******************************************************************************/

/*******************************************************************************
  * @brief  lv1_idle_entry 子状态进入，在进入当前状态时执行一次
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv1_idle_entry(void *fsmp)
{
	(void)fsmp; /* warning fix */
	
	fsme_usr_log("\n\rEntry[lv1/idle].\n");
}

/*******************************************************************************
  * @brief  lv1_idle_exit 子状态退出，在退出当前状态时执行一次
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv1_idle_exit(void *fsmp)
{
	(void)fsmp; /* warning fix */
	
	fsme_usr_log("\n\rExit[lv1/idle].");
}

/*******************************************************************************
  * @brief  lv1_idle_action 子状态轮询，每次轮询fsm时执行一次
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv1_idle_action(void *fsmp)
{
    static int cnt;
	(void)fsmp; /* warning fix */
	
	fsme_usr_log("\rAction[lv1/idle]-[%d].", cnt++);
}

/*******************************************************************************
  * @brief  lv1_edit_entry
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv1_edit_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsm->timeout = fsme_get_tick_count() + 3 * 1000;
	fsme_usr_log("\n\rEntry[lv1/edit], Set timeout 3s");
}

/*******************************************************************************
  * @brief  lv1_fault_entry
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv1_fault_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsm->timeout = fsme_get_tick_count() + 5 * 1000;
	fsme_usr_log("\n\rEntry[lv1/fault], Set timeout 5s");
}



/*******************************************************************************
  * @brief  Trans table 跳转表
  *****************************************************************************/

static const fsme_trans_t Lv1_Trans_Idle[] =
{
    {lv1_event_key1,		LV1_STATE_EDIT},
};

static const fsme_trans_t Lv1_Trans_Edit[] =
{
    {lv1_event_timeout,		LV1_STATE_LV2},
};

static const fsme_trans_t Lv1_Trans_Lv2[] =
{
    {lv1_event_lv2_exit_1, 	LV1_STATE_FAULT},
	{lv1_event_lv2_exit_2, 	LV1_STATE_IDLE},
};

static const fsme_trans_t Lv1_Trans_Fault[] =
{
    {lv1_event_key1,		LV1_STATE_IDLE},
	{lv1_event_timeout,		LV1_STATE_FAULT},
};



/*******************************************************************************
  * @brief  Entire table : state outputs and transitions. 
*	@note	action的名称顺序必须要和本文件对应头文件里的枚举xxx_fsm_state_t 定义一致
  *****************************************************************************/
static const fsme_state_t Lv1_Fsm_States[] =
{
	/* action,       	entry,          exit,         	event, event_num,             		name */
	{lv1_idle_action,	lv1_idle_entry,	lv1_idle_exit,	ARRAY_AND_SIZE(Lv1_Trans_Idle), 	"Lv1_Idle"},
	{NULL,				lv1_edit_entry,	NULL,			ARRAY_AND_SIZE(Lv1_Trans_Edit), 	"Lv1_Edit"},
	{lv2_fsm_run,		lv2_fsm_start,	lv2_fsm_stop,	ARRAY_AND_SIZE(Lv1_Trans_Lv2), 	    "Lv1_Lv2"},
	{NULL,				lv1_fault_entry,NULL,			ARRAY_AND_SIZE(Lv1_Trans_Fault), 	"Lv1_Fault"},
};


/*******************************************************************************
  * @brief  fsm init
  * @param  *fsmp
  * @retval none
  * @note   状态机进入函数，常用作复位状态机初值
    @ ARRAY_AND_SIZE(App_Trans_Fault) 包含 跳转表 App_Trans_Fault 和 数量 2。
    @ 如果接口中出现 zzz_fsm_run / zzz_fsm_start / zzz_fsm_stop 说明包含和子状态机。
  *****************************************************************************/
static void lv1_fsm_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp; //获取状态机指针
	
	fsm->current_state 	= LV1_STATE_IDLE,
	fsm->trans 			= Lv1_Trans_Idle;
	fsm->trans_nbr 		= ARRAY_SIZE(Lv1_Trans_Idle);
    
    fsme_usr_log("\n\rStart[lv1]\r\n-------------");
}


/*******************************************************************************
  * @brief  Lv1_Fsm
  *****************************************************************************/
fsme_t Lv1_Fsm = {
	false,									//enable
	LV1_STATE_IDLE,							//current_state
	ARRAY_AND_SIZE(Lv1_Fsm_States),			//*states
											//states_nbr
	ARRAY_AND_SIZE(Lv1_Trans_Idle),			//*trans
											//trans_nbr
	0,										//timeout
	0,										//timeout_flag
    0,										//timer
    0,										//last_state
    LV1_STATE_IDLE,							//last_event
	lv1_fsm_entry,							//fsm_entry 状态机进入函数，常用作复位状态机初值
	NULL,									//fsm_exit 状态机退出函数，可用于子状态机退出统一接口
	0,										//exit_flag
	"lv1"								    //*name
};


/*******************************************************************************
  * @brief  fsm start
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
void lv1_fsm_start(void *fsmp)
{
	(void)fsmp; /* warning fix */
	
	fsm_enable(&Lv1_Fsm);
}


/*******************************************************************************
  * @brief  fsm polling
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
void lv1_fsm_run(void *fsmp)
{
	fsmp = fsmp; /* warning fix */
	
	fsm_run(&Lv1_Fsm);
}

/*******************************************************************************
  * @brief  fsm stop
  * @param  *fsmp
  * @retval None
  * @note   [this function is not used]
  *****************************************************************************/
void lv1_fsm_stop(void *fsmp)
{
	fsmp = fsmp; /* warning fix */
	
	fsm_disable(&Lv1_Fsm);
}

/********************************* end of file ********************************/





