/**
  ******************************************************************************
  * @file    fsm_lv2.c
  * @author  SeanLi
  * @version 
  * @date    04-December-2017
  * @brief   
  *
  *                      
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

/*******************************************************************************
************************************ Includes **********************************
*******************************************************************************/

#include "fsm_lv2.h"
#include "fsm_lv1_action.h"
#include "fsm_lv1_event.h"

/*******************************************************************************
******************************** Private typedef *******************************
*******************************************************************************/

/*******************************************************************************
******************************** Private define ********************************
*******************************************************************************/

/*******************************************************************************
********************************* Private macro ********************************
*******************************************************************************/

/*******************************************************************************
******************************* Private variables ******************************
*******************************************************************************/

/*******************************************************************************
************************** Private function prototypes *************************
*******************************************************************************/

/*******************************************************************************
******************************* Private functions ******************************
*******************************************************************************/


/*******************************************************************************
  * @brief  lv2_start_entry
  * @param  void *fsmp
  * @retval none
  *****************************************************************************/
static void lv2_start_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsm->timer = fsme_get_tick_count() + 5 * 1000;
	fsme_usr_log("\n\rEntry[lv2/start], Set timer 5s");
}

/*******************************************************************************
  * @brief  lv2_s1_entry
  * @param  void *fsmp
  * @retval none
  *****************************************************************************/
static void lv2_s1_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsm->timeout = fsme_get_tick_count() + 5 * 1000;
	fsme_usr_log("\n\rEntry[lv2/s1], Set timeout 5s");
}

/*******************************************************************************
  * @brief  lv2_exit1_entry
  * @param  void *fsmp
  * @retval none
  *****************************************************************************/
static void lv2_exit1_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsme_usr_log("\n\rEntry[lv2/exit1].\n");
	
	fsm->exit_flag = LV2_EXIT_1;//状态机退出
}

/*******************************************************************************
  * @brief  lv2_exit2_entry
  * @param  void *fsmp
  * @retval none
  *****************************************************************************/
static void lv2_exit2_entry(void *fsmp)
{
	fsme_t *fsm = (fsme_t *)fsmp;

	fsme_usr_log("\n\rEntry[lv2/exit2].");
	//状态机退出
	fsm->exit_flag = LV2_EXIT_2;
}



/*******************************************************************************
  * @brief  Trans table
  *****************************************************************************/

static const fsme_trans_t Lv2_Trans_Start[] =
{
    {lv1_event_key1,		LV2_STATE_S1},
	{lv1_event_timer,		LV2_STATE_EXIT2},
};

static const fsme_trans_t Lv2_Trans_S1[] =
{
    {lv1_event_timeout,		LV2_STATE_EXIT1},
};

static const fsme_trans_t Lv2_Trans_Exit1[] =
{
    {lv1_event_timeout,		LV2_STATE_EXIT1},//退出状态项, 用超时转移填充,避免为空(fsme_update_state至少查一次)
};

static const fsme_trans_t Lv2_Trans_Exit2[] =
{
    {lv1_event_timeout,		LV2_STATE_EXIT2},//退出状态项, 用超时转移填充,避免为空(fsme_update_state至少查一次)
};



/*******************************************************************************
  * @brief  Entire table : state outputs and transitions. 
  *	@note	顺序必须和 xxx_fsm_state_t 一致
  *****************************************************************************/
static const fsme_state_t Lv2_Fsm_States[] =
{
	/* action,	entry,          	exit,	event, event_num,             		name */
	{NULL,		lv2_start_entry,	NULL,	ARRAY_AND_SIZE(Lv2_Trans_Start), 	"Lv2_Start"},
	{NULL,		lv2_s1_entry,		NULL,	ARRAY_AND_SIZE(Lv2_Trans_S1), 		"Lv2_S1"},
	{NULL,		lv2_exit1_entry,	NULL,	ARRAY_AND_SIZE(Lv2_Trans_Exit1), 	"Lv2_Exit1"},
	{NULL,		lv2_exit2_entry,	NULL,	ARRAY_AND_SIZE(Lv2_Trans_Exit2), 	"Lv2_Exit2"},
	
};


/*******************************************************************************
  * @brief  fsm init
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
static void lv2_fsm_entry(void *fsmp)
{
	fsme_t *f = (fsme_t *)fsmp;
	
	f->current_state 	= LV2_STATE_START,
	f->trans 			= Lv2_Trans_Start;
	f->trans_nbr 		= ARRAY_SIZE(Lv2_Trans_Start);

    f->exit_flag = 0;
    
    fsme_usr_log("\n\rStart[lv2]\r\n-------------");

}


/*******************************************************************************
  * @brief  Prog_Fsm
  *****************************************************************************/
fsme_t Lv2_Fsm = {
	false,									//enable
	LV2_STATE_START,						//current_state
	ARRAY_AND_SIZE(Lv2_Fsm_States),		    //*states
											//states_nbr
	ARRAY_AND_SIZE(Lv2_Trans_Start),		//*trans
											//trans_nbr
	0,										//timeout
	0,										//timeout_flag
    0,										//timer
    0,										//last_state
    LV2_STATE_START,						//last_event
	lv2_fsm_entry,							//fsm_entry
	NULL,									//fsm_exit
	0,										//exit_flag
	"fsm lv2"								//*name
};


/*******************************************************************************
  * @brief  fsm start
  * @param  *fsmp
  * @retval none
  * @note will call eg. lv2_fsm_entry() and lv2_start_entry()
  *****************************************************************************/
void lv2_fsm_start(void *fsmp)
{
	fsmp = fsmp; /* warning fix */
	
	fsm_enable(&Lv2_Fsm);
}


/*******************************************************************************
  * @brief  fsm polling
  * @param  *fsmp
  * @retval none
  *****************************************************************************/
void lv2_fsm_run(void *fsmp)
{
	fsmp = fsmp; /* warning fix */
	
	fsm_run(&Lv2_Fsm);
}

/*******************************************************************************
  * @brief  fsm stop
  * @param  *fsmp
  * @retval None
  *****************************************************************************/
void lv2_fsm_stop(void *fsmp)
{
	fsmp = fsmp; /* warning fix */
	
	fsm_disable(&Lv2_Fsm);
}


/********************************* end of file ********************************/





