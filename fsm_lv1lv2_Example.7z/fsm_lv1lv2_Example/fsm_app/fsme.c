/**
  ******************************************************************************
  * @file    fsme.c
  * @author  SeanLi
  * @version 
  * @date    04-December-2017
  * @brief   
  *
  *                      
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

/*******************************************************************************
************************************ Includes **********************************
*******************************************************************************/
#include "fsme.h"

/*******************************************************************************
******************************** Private typedef *******************************
*******************************************************************************/

/*******************************************************************************
******************************** Private define ********************************
*******************************************************************************/

/*******************************************************************************
********************************* Private macro ********************************
*******************************************************************************/

/*******************************************************************************
******************************* Private variables ******************************
*******************************************************************************/

/*******************************************************************************
************************** Private function prototypes *************************
*******************************************************************************/

/*******************************************************************************
******************************* Private functions ******************************
*******************************************************************************/

/*******************************************************************************
  * @brief  fsme_update_state 检查当前状态项的转移表,在转移时执行转移操作
  * @param  fsm
  * @retval none
  * @note   由fsm_run调用.
			执行内容:
			1. 顺序检查当前状态项的转移表, (只首次执行)若发生转移,即
			trans[i].event()返回1,则执行当前状态项的退出函数state[S].exit_action().
			2. 同时更新状态机新状态项的内容(旧状态项号, 旧状态项的转移事件号, 
			新状态项号, 新状态项的转移表, 新状态项的转移表长度)
			3. 执行新状态项的进入函数 state[S'].entry_action()
			4. 清除超时标志
  *****************************************************************************/
static void fsme_update_state(fsme_t *fsm)
{
	size_t i = 0;
	size_t nbr;
	const fsme_trans_t *p_trans;
	const fsme_state_t *p_state;

	// set a variable to point to current transition table
	p_trans = fsm->trans;
	
	// set a variable to current value of transitions count for current state
	nbr = fsm->trans_nbr;
	
	// loop for all possible transitions from current state
	for (i=0; i<nbr; i++){
		
		// check if the events have occured
		// (conditions are true for a transition to take place)
		if(true == p_trans[ i ].event(fsm)){
			if (fsm->states[fsm->current_state].exit_action){
				fsm->states[fsm->current_state].exit_action(fsm);
            }
			// 下面填写新的(状态机)状态项的属性内容
            // record last state and triggering event**
            fsm->last_state = fsm->current_state;
            fsm->last_event = i;
			
			// update current state
			fsm->current_state = p_trans[ i ].next_state;
			
			// get a pointer to current state
			p_state = & ( fsm->states[ fsm->current_state ] );
			fsme_dbg_log("\rFSM from [%s]->[%s]\n", fsm->name, p_state->name);
			
			// update current transition table according to current state
			fsm->trans = p_state->trans;
			
			// update current transitions number according to current state
			fsm->trans_nbr = p_state->trans_nbr;
			if (fsm->states[fsm->current_state].entry_action){
				fsm->states[fsm->current_state].entry_action(fsm); 
            }
			
            // clear timeout flag
            fsm->timeout_flag = false;
			
			// leave the for loop and function
			break;
		}
	}
}

/*******************************************************************************
  * @brief  fsme_action
  * @param  fsm
  * @retval none
  *****************************************************************************/
static void fsme_action(fsme_t *fsm)
{
	if (fsm->states[fsm->current_state].action){
		fsm->states[fsm->current_state].action(fsm);
	}
}

/*******************************************************************************
  * @brief  fsm_run
  * @param  fsm
  * @retval none
  *****************************************************************************/
void fsm_run(fsme_t *fsm)
{
	if (false == fsm->enable){
		return;
	}
	fsme_action(fsm);
	fsme_update_state(fsm);
	fsme_dbg_log("\rFSM '%s' is running", fsm->name);
}

/*******************************************************************************
  * @brief  fsm_enable
  * @param  fsm
  * @retval none
  *****************************************************************************/
void fsm_enable(fsme_t *fsm)
{
	fsm->enable      = true;
	
	if (fsm->fsm_entry){
		fsm->fsm_entry(fsm);
	}
	if (fsm->states[fsm->current_state].entry_action){
		fsm->states[fsm->current_state].entry_action(fsm); 
		fsm->timeout_flag = false;
	}
	fsme_dbg_log("\r\nFSM '%s' is enabled", fsm->name);
}

/*******************************************************************************
  * @brief  fem_disable
  * @param  fsm
  * @retval none
  *****************************************************************************/
void fsm_disable(fsme_t *fsm)
{
	fsm->enable = false;
	if (fsm->fsm_exit)
		fsm->fsm_exit(fsm);
	fsme_dbg_log("FSM: '%s' is disabled\n", fsm->name);
}

/********************************* end of file ********************************/





